package ru.skillbranch.devintensive

import org.junit.Test

import org.junit.Assert.*
import ru.skillbranch.devintensive.models.*
import ru.skillbranch.devintensive.utils.Utils
import java.util.*
import android.text.format.DateUtils
import ru.skillbranch.devintensive.extensions.*


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {


    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }



    @Test
    fun testUserFactory() {
        val nameCycle = 'a'..'z'

        nameCycle.forEach {
            println(User.makeUser("${it.toUpperCase()} $it"))
        }

    }



    @Test
    fun testUser() {
        println(User.makeUser(""))
    }



    @Test
    fun testHumanizeDiff() {
        val dateBef = Date().add(-5, TimeUnits.DAY)
        println(dateBef.humanizeDiff())

        assertEquals(Date().add(-2, TimeUnits.HOUR).humanizeDiff(), "2 часа назад") //2 часа назад
        assertEquals(Date().add(-5, TimeUnits.DAY).humanizeDiff(), "5 дней назад")//5 дней назад
        assertEquals(Date().add(2, TimeUnits.MINUTE).humanizeDiff(), "через 2 минуты")//через 2 минуты
        assertEquals(Date().add(7, TimeUnits.DAY).humanizeDiff(), "через 7 дней")//через 7 дней
        assertEquals(Date().add(-400, TimeUnits.DAY).humanizeDiff(), "более года назад")//более года назад
        assertEquals(Date().add(400, TimeUnits.DAY).humanizeDiff(), "более чем через год") //более чем через год

    }



    @Test
    fun testFormatMessage() {

        assertEquals(
            TextMessage(
                "1",
                User.makeUser("Василий Ваильевич"),
                Chat("1"),
                false,
                Date(),"any text message").formatMessage(
            ), "Василий отправил сообщение \"any text message\" только что"
        )


        assertEquals(
            ImageMessage(
                "2",
                User.makeUser("Василий Ваильевич"),
                Chat("1"),
                true,
                Date().add(-2, TimeUnits.HOUR),"https://anyurl.com").formatMessage()
                , "Василий получил изображение \"https://anyurl.com\" 2 часа назад"
        )
    }



    @Test
    fun testParseFullName() {
        println(Utils.parseFullName(null))
        println(Utils.parseFullName(""))
        println(Utils.parseFullName(" "))
        println(Utils.parseFullName("John"))
    }



    @Test
    fun testDateFormat() {
        println(Date().format("HH:mm"))
    }



    @Test
    fun testTimeAdd() {
        println(Date().add(10, TimeUnits.DAY))
    }



    @Test
    fun testInitials() {
        assertEquals(Utils.toInitials("john", "doe"), "JD")
        assertEquals(Utils.toInitials("John", null), "J")
        assertEquals(Utils.toInitials(null, null), null)
        assertEquals(Utils.toInitials(" ", ""), null)
        //al str = Utils.toInitials("Fvbb", "hj")
        //rintln(str)
    }



    @Test
    fun testTransliteral() {
        println(Utils.transliteration("Павел Крюков"))
        println(Utils.transliteration("Павел Крюков", "_"))
    }



    @Test
    fun testUserView() {
        val user = User.makeUser("Иванов Иван")
        user.toUserView()
        println(user)
    }



    @Test
    fun builderTest() {
        val user = User.Builder().id("2")
            .firstName("John")
            .lastName("Doe")
            .avatar("someurl")
            .rating(55)
            .respect(10)
            .lastVisit(Date())
            .isOnline(false)
            .build()

        assert(user is User)

        //println(user)
    }



    @Test
    fun nuberDeclinationTesting() {
        println(Utils.numbersDeclination("238", "hours"))
    }



    @Test
    fun testTruncateWithoutArgs() {

        assertEquals(
            "Bender Bending Rodriguez — дословно «Сгибальщик Сгибающий Родригес»".truncate(),
            "Bender Bending R..."
        )
        assertEquals(
            "Bender Bending Rodriguez — дословно «Сгибальщик Сгибающий Родригес»".truncate(15),
            "Bender Bending..."
        )
        assertEquals("A     ".truncate(3), "A...")

    }



    @Test
    fun cleanHtmlTest() {
        assertEquals(
            "<p class=\"title\">Образовательное IT-сообщество Skill Branch</p>".stripHtml(),
            "Образовательное IT-сообщество Skill Branch"
        )
        assertEquals(
            "<p>Образовательное       IT-сообщество Skill Branch</p>".stripHtml(),
            "Образовательное IT-сообщество Skill Branch"
        )

    }



    @Test
    fun timeunitPluralTest() {
        assertEquals(TimeUnits.SECOND.plural(1), "1 секунду")
        assertEquals(TimeUnits.MINUTE.plural(4), "4 минуты")
        assertEquals(TimeUnits.HOUR.plural(19), "19 часов")
        assertEquals(TimeUnits.DAY.plural(222), "222 дня")

    }

}
